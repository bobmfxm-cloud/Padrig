# Pints of Galway

Standalone HTML5 canvas game.

## Run locally

Open `index.html` in a browser.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload these files to the repository root:
   - `index.html`
   - `.nojekyll`
   - `README.md`
3. Go to repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder.
6. Save and wait a few minutes for GitHub Pages to publish.

Your game will usually be available at:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY-NAME/`
